﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuctionsPortal.Admin.Model
{
    public class ItemEventArgs : EventArgs
    {

        public Int32 ItemId { get; set; }
    }
}
