#ifndef THREADNUMBERSETDIALOG_H
#define THREADNUMBERSETDIALOG_H

#include <QObject>
#include <QDialog>
#include <QPushButton>
#include <QVBoxLayout>
#include "amountsetter.h"

namespace TexasHoldemView
{
class ThreadNumberSetDialog : public QDialog
{
    Q_OBJECT
public:
    explicit ThreadNumberSetDialog(QWidget *parent = 0);
    ~ThreadNumberSetDialog();

signals:

public slots:

public:
    int getNOfThreads() {return _threadSetter->getAmount();}

private:
    AmountSetter* _threadSetter;
    QPushButton *_okButton;
    QPushButton *_rejectButton;

    QHBoxLayout* _buttonLayout;
    QVBoxLayout* _mainLayout;

};
}



#endif // THREADNUMBERSETDIALOG_H
