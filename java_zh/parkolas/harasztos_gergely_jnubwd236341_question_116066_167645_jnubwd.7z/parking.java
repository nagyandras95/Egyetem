import java.util.*;
class Officer{
		private ArrayList<Meter> meters;
		void addMeter(Meter m){meters.add(m);}
		Officer(){};
		public Integer  getFaultyIncome(){
			Integer total = 0;
			Meter u = new FaultyMeter("s",3,3);
			for(Meter i :  meters) {
				
				if(u.hashCode()==((FaultyMeter)i).hashCode()){
				total = total + ((FaultyMeter)i).getFaultIncome();
				}
			}
			return total;
		}
		public Integer  getLegalIncome(){
			Integer total = 0;
			for (Meter i : meters){
				total = total + i.getIncome();
			}
			return total;
		}
		
		public Integer getTotalIncome(){
			Integer total = 0;
			total = getFaultyIncome() + getLegalIncome();
			return total;
		}
	}
class FaultyMeter extends Meter{
	private Integer faultIncome;
	private Integer faultRate;
	
	
	FaultyMeter(String n ,Integer c, Integer fr){
		super(n,c);
		name = n;
		faultIncome = 0;
		faultRate = fr;
		income = 0;
		ticketsGiven = 0;
		costPerHour = c;
	}
	
	public Ticket buy(Integer p,Integer e){
		if(faultRate == ticketsGiven){
		String i = "";
		Integer time = (p/costPerHour)+e;
		Ticket h = new Ticket(i,p,time);
		ticketsGiven = ticketsGiven + 1;
		faultIncome = faultIncome + p;
		return h;
		}
		String i = name + "_" + ticketsGiven;
		Integer time = (p/costPerHour)+e;
		Ticket h = new Ticket(i,p,time);
		
		ticketsGiven = ticketsGiven + 1;
		income = income + p;
		
		return h;
	}
	
	public Ticket extend(Integer p, Ticket j){
		if(faultRate == ticketsGiven){
		faultIncome = faultIncome + p;
		ticketsGiven = ticketsGiven + 1;
		Ticket h = new Ticket(j.getId(),j.getPrice(),j.end());
		return h;
		}
		if(j.isValid()){
		Integer time = (p/costPerHour)+j.end();
		income = income + p;
		ticketsGiven = ticketsGiven + 1;
		Ticket h = new Ticket(j.getId(),j.getPrice()+p,time);
		return h;}else{
			throw new InvalidTicketException(j);
		}
	}
	
	public Integer getFaultIncome(){ return faultIncome; }
}
class Ticket{
	private final String  id;
	private Integer price;
	private Integer end;
	public String getId(){ return id; }
	public Integer getPrice(){ return price; }
	public String getEnd(){ return end+":"+"00"; }	//mert egesz orakkor jar le a feladat szerint
	
	//segedfuggveny az extendhez
	public Integer end(){ return end;} 
	//
	
	Ticket(String i,Integer p, Integer e){
		if(i==null){throw new IllegalArgumentException();}
		else{id = i;}
		if(p<0){throw new IllegalArgumentException();}
		else{price = p;}
		end = e;
	}
	
	
	Ticket(Integer p, Integer e){
		id = "";
		price = p;
		end = e;
	}
	
	public boolean isValid(){
		if(getId() != "" && getPrice() >= 0){ return true;} else {return false;}
	}
	
	void extend(Integer p, Integer e){
		price = price + p;
		end = end + e;
	}

	void tostring(){
		System.out.println(getId());
		System.out.println("Price: "+getPrice()+" Ft");
		System.out.println("Valid until: "+getEnd());	
		
	}
	
@Override
	public  boolean equals(Object o){
		if(((Ticket)o).getId() == this.getId()){
			return true;
				}else{
			return false;
			}
	}
}
class InvalidTicketException extends RuntimeException{
	InvalidTicketException(Object o){
		super("InvalidTicketException");
	}
}

interface ParkingMeter{
	public Ticket buy(Integer p,Integer e);
	public Ticket extend(Integer p, Ticket j);
}

class Meter implements ParkingMeter{
	String name;
	Integer ticketsGiven;
	Integer costPerHour;
	Integer income;
	
	public Ticket buy(Integer p,Integer e){
		String i = name + "_" + ticketsGiven;
		Integer time = (p/costPerHour)+e;
		Ticket h = new Ticket(i,p,time);
		
		ticketsGiven = ticketsGiven + 1;
		income = income + p;
		
		return h;
	}
	
	public Ticket extend(Integer p, Ticket j){
		if(j.isValid()){
		Integer time = (p/costPerHour)+j.end();
		income = income + p;
		ticketsGiven = ticketsGiven + 1;
		Ticket h = new Ticket(j.getId(),j.getPrice()+p,time);
		return h;}else{
			throw new InvalidTicketException(j);
		}
	}
	
	Meter(String n,Integer c){
		name = n;
		costPerHour = c;
		income = 0;
		ticketsGiven = 0;
	}

public Integer getIncome(){ return income; }
}
class parking{
	public static void main (String[] args) {
		//illegalargumentexception
		// Ticket t = new Ticket("",88,2);
		// Ticket t = new Ticket("1234",-1,2);
		
		//Ticket t = new Ticket("1234",88,2);
		//Ticket y = new Ticket("1254",88,2);
		//t.tostring();
		// System.out.println(y.equals(t));
		
	//	Meter m = new Meter("duno",20);
		//Meter b = new Meter("donto",20);
		//Meter c = new Meter("dinono",20);
		//Meter f = new FaultyMeter("sss",29,2);
		//m.buy(40,2);m.buy(40,2);m.buy(40,2);m.buy(40,2);m.buy(40,2);m.buy(40,2);m.buy(40,2);
		//f.buy(40,2);f.buy(40,2);f.buy(40,2);f.buy(40,2);f.buy(40,2);f.buy(40,2);f.buy(40,2);f.buy(40,2);f.buy(40,2);
		//Officer o = new Officer();
		//o.addMeter(m);
		//o.addMeter(b);
		//o.addMeter(c);
		//System.out.println(o.getTotalIncome());
	}
}